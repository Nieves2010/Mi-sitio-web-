
document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault(); // Evitar el envío del formulario para la demostración
    alert("Gracias por contactarnos! Pronto estaremos en contacto contigo.");
});
